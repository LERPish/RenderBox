#ifndef INPUT_H
#define INPUT_H

char doInput(void); 

#endif
