#ifndef DEFS_H
#define DEFS_H

#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

#endif
