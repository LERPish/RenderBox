#ifndef INIT_H
#define INIT_H
#include "structs.h"

extern App app;

void initSDL();

#endif
