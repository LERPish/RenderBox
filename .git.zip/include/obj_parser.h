#ifndef OBJ_PARSER_H
#define OBJ_PARSER_H
#include "math_utils.h"
#include "entities.h"

Mesh *LoadOBJ(const char *filename);

#endif
